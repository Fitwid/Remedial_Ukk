<?php
// koneksi ke database
$conn = mysqli_connect("localhost", "root", "root", "phpdasar");

// ambil data dari tabel mahasiswa / query data mahasiswa
$result = mysqli_query($conn, "SELECT * FROM mahasiswa")

?>
<!DOCTYPE html>
<html>
<head>
    <title>Halaman Admin</title>
</head>
<body>
    
<h1>Daftar Mahasiswa</h1>

<table border="1" cellpadding="1" cellspacing="0">

    <tr>
        <th>No.</th>
        <th>Aksi</th>
        <td>Gambar</th>
        <th>NRP</th>
        <th>Nama</th>
        <th>Email</th>
        <th>Jurusan</th>
    </tr>


    <tr>
        <td>1</td>
        <td>
            <a href="">ubah</a>
            <a href="">hapus</a>
        </td>
        <td><img src=""></td>
        <td>083877999564</td>
        <td>fitri</td>
        <td>fitri@smk.BinaCendekia.id</td>
        <td>pllg2</td>
    </tr>

</table>

</body>
</html>


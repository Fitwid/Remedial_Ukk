<h1 class="mt-4">Kategori Buku</h1>
<div class="row"
<div class="col-md-12">
    <table class="table table-borderet">
        <tr>
            <th>No</th>
            <th>Nama Kategori</th>
            <th>aksi</th>
            <th>penulis</th>
            <th>penerit</th>
            <th>Aksi</th>
</tr>
<?php
$i =1;
squery = mysqli_query($kineksi, "SELECT*FROM" kategori");
while($data = mysqli_fetch_array($query)){
?>
<td><?php echo $i++; ?></td>
<td><?php echo $idata['kategori']; ?></td>
</td>
<a href="?page=kategori_uah$$id=<?php echo $idata['id kategori']; ?>" class=btn btn-info"><ubah</a>
<a href="?page=kategori_uah$$id=<?php echo $idata['id kategori']; ?>" class=btn btn-info"><hapus</a>

<?php





</table>
</div>
</div>